/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.eft_s9_felipe_flores;

/**
 *
 * @author pelaoo
 */
public class EFT_S9_Felipe_Flores {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
